#!/bin/bash
set -e
cd "$(dirname "$0")"
clear
printf '\nGitHub 저장소로 폴더 구조 그대로 업로드합니다.\n\n'
if ! command -v git >/dev/null 2>&1; then
  echo 'git이 설치되어 있지 않습니다. 먼저 Xcode Command Line Tools를 설치합니다.'
  xcode-select --install || true
  read -n 1 -s -r -p '설치가 끝난 뒤 이 파일을 다시 실행하세요.'
  exit 1
fi
read -p '비어 있는 GitHub 저장소 주소를 붙여넣으세요 (예: https://github.com/아이디/aedong-saju.git): ' REPO
if [ -z "$REPO" ]; then
  echo '저장소 주소가 비어 있습니다.'
  exit 1
fi
[ -d .git ] || git init
git branch -M main
git add .
git commit -m 'Deploy aedong saju MVP' || true
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO"
git push -u origin main --force
printf '\n업로드 완료. GitHub 저장소를 새로고침하세요.\n'
read -n 1 -s -r -p '아무 키나 누르면 창을 닫습니다.'
