#!/bin/bash
set -e
cd "$(dirname "$0")"
clear
printf '\n애동제자의 사주풀이 배포를 시작합니다.\n\n'
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js가 설치되어 있지 않습니다.'
  echo '브라우저에서 https://nodejs.org 를 열어 LTS 버전을 설치한 뒤 다시 실행하세요.'
  open 'https://nodejs.org'
  read -n 1 -s -r -p '아무 키나 누르면 종료합니다.'
  exit 1
fi

echo '1/3 프로젝트 파일 구조 확인 중...'
for f in package.json app/page.tsx app/layout.tsx app/api/analyze/route.ts lib/reading.ts; do
  if [ ! -f "$f" ]; then
    echo "필수 파일이 없습니다: $f"
    read -n 1 -s -r -p '아무 키나 누르면 종료합니다.'
    exit 1
  fi
done

echo '2/3 Vercel 로그인 및 프로젝트 연결...'
echo '브라우저가 열리면 Vercel에 로그인하고 승인하세요.'
npx --yes vercel@latest link

echo '3/3 운영 배포 중...'
npx --yes vercel@latest --prod

echo '\n배포가 완료되었습니다. 위에 표시된 Production URL을 열어 확인하세요.'
read -n 1 -s -r -p '아무 키나 누르면 창을 닫습니다.'
